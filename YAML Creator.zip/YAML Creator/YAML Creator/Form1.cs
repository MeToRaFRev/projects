﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Net.Http;
using System.Web;
using System.Net;

namespace YAML_Creator
{
    public partial class Form1 : Form
    {
        string fileContent;
        string errormessage;
        public Form1()
        {
            InitializeComponent();
        }
        public static byte[] GetHash(string inputString)
        {
            using (HashAlgorithm algorithm = SHA256.Create())
                return algorithm.ComputeHash(Encoding.UTF8.GetBytes(inputString));
        }
        public static string GetHashString(string inputString)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(inputString))
                sb.Append(b.ToString("X2"));

            return sb.ToString();
        }
        private void Generate_Button_Click(object sender, EventArgs e)
        {
            TimeSpan t = DateTime.UtcNow - new DateTime(1970, 1, 1);
            int secondsSinceEpoch = (int)t.TotalSeconds;
            var generate = true;
            if (String.IsNullOrEmpty(PM_Entry.Text)) { generate = false; };
            if (String.IsNullOrEmpty(SS_Entry.Text)) { generate = false; };
            if (String.IsNullOrEmpty(TS_Entry.Text)) { generate = false; };
            if (String.IsNullOrEmpty(User_Entry.Text)) { generate = false; };
            if (String.IsNullOrEmpty(UoS_Entry.Text)) { generate = false; };
            if (String.IsNullOrEmpty(Filename_Label.Text)) { generate = false; };
            if (String.IsNullOrEmpty(Env_Entry.Text)) { generate = false; };
            if (generate == true)
            {
                string yamlfile = secondsSinceEpoch + ":\n Project Manager: " + PM_Entry.Text + "\n Source System: " + SS_Entry.Text + "\n Target System: " + TS_Entry.Text + "\n User of Service: " + User_Entry.Text + "\n Usage of Service: " + UoS_Entry.Text + "\n Enviorment: " + Env_Entry.Text + "\n URL: " + Url_Entry.Text + "\n Method: " + Method_Entry.Text + "\n Schema: \n   " + fileContent + "\n Request Example: \n   " + ReqExam_Entry.Text + "\n Response Example: \n    " + ResExam_Entry.Text;
                string yamlhash = GetHashString(yamlfile);
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Filter = "yaml files (*.yaml)|*.yaml";
                saveFileDialog1.RestoreDirectory = true;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(saveFileDialog1.FileName, yamlfile + "\n Hash: " + yamlhash);
                }
            }
            else {
                MessageBox.Show ("ישנה בעיה בשדות הקלט", "שגיאת קלט", MessageBoxButtons.OK,
              MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            }
        }

        private void Schema_Button_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "C# Corner Open File Dialog";
            fdlg.InitialDirectory = @"c:\";
            fdlg.Filter = "json files (*.json)|*.json|txt files (*.txt)|*.txt|yaml files(*.yaml) | *.yaml";
            fdlg.FilterIndex = 1;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                Filename_Label.Text = Path.GetFileName(fdlg.FileName);
                var fileStream = fdlg.OpenFile();
                using (StreamReader reader = new StreamReader(fileStream))
                {
                    fileContent = reader.ReadToEnd();
                }
            }
        }

        private void PM_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("מנהל פרוייקט : אביאל לוי", "דוגמא למנהל פרוייקט", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void SS_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("מערכת מקור: CRM", "דוגמא למערכת מקור", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void TS_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("מערכת יעד: Clicks", "דוגמא למערכת יעד", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void User_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("צרכן השירות: מכבי אונליין", "דוגמא לצרכן שירות", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void UoS_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("מהות השירות: קבלת TOKEN", "דוגמא למהות השירות", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }
        private void Url_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("כתובת השירות: https://push-test.mac.org.il/api/Identity/v1/Token", "דוגמא לכתובת השירות", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }
        private void Schema_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("סוג הקובץ חייב להיות : json,yaml,txt", "צרף קובץ סכמה", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void ReqExam_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("חייב להיות תוכן json", "דוגמת קריאה", MessageBoxButtons.OK,
MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
        }

        private void RestCheck_Button_Click(object sender, EventArgs e)
        {
            var restWorks = true;
            if (String.IsNullOrEmpty(Method_Entry.Text)) { restWorks = false; };
            if (String.IsNullOrEmpty(Url_Entry.Text)) { restWorks = false; };
            if (Url_Entry.Text.Contains(';')) { restWorks = false; };
            var URL = Url_Entry.Text;
            var DATA = ReqExam_Entry.Text;
            if (restWorks != false)
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = Method_Entry.Text;
                if (request.Method != "GET")
                {
                    request.ContentType = "application/json";
                    request.ContentLength = DATA.Length;
                    StreamWriter requestWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                    requestWriter.Write(DATA);
                    requestWriter.Close();
                }
                try
                {
                    WebResponse webResponse = request.GetResponse();
                    Stream webStream = webResponse.GetResponseStream();
                    StreamReader responseReader = new StreamReader(webStream);
                    Statuscode_Label.Text = "Success";
                    string response = responseReader.ReadToEnd();
                    ResExam_Entry.Text = response;
                    responseReader.Close();
                }
                catch (Exception a)
                {
                    errormessage = a.ToString();
                    Statuscode_Label.Text = "Exception";
                    restWorks = false;
                }
            }
        }

        private void Arrow_Label_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!String.IsNullOrEmpty(errormessage))
            {
                MessageBox.Show(errormessage, "Advanced Error", MessageBoxButtons.OK);
            }
        }
    }
}
