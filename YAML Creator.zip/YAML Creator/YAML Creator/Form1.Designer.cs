﻿namespace YAML_Creator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PM_Label = new System.Windows.Forms.LinkLabel();
            this.SS_Label = new System.Windows.Forms.LinkLabel();
            this.UoS_Label = new System.Windows.Forms.LinkLabel();
            this.Url_Label = new System.Windows.Forms.LinkLabel();
            this.Schema_Label = new System.Windows.Forms.LinkLabel();
            this.ReqExam_Label = new System.Windows.Forms.LinkLabel();
            this.ResExam_Label = new System.Windows.Forms.LinkLabel();
            this.TS_Label = new System.Windows.Forms.LinkLabel();
            this.User_Label = new System.Windows.Forms.LinkLabel();
            this.PM_Entry = new System.Windows.Forms.TextBox();
            this.SS_Entry = new System.Windows.Forms.TextBox();
            this.TS_Entry = new System.Windows.Forms.TextBox();
            this.User_Entry = new System.Windows.Forms.TextBox();
            this.UoS_Entry = new System.Windows.Forms.TextBox();
            this.Url_Entry = new System.Windows.Forms.TextBox();
            this.Schema_Button = new System.Windows.Forms.Button();
            this.Filename_Label = new System.Windows.Forms.Label();
            this.Method_Entry = new System.Windows.Forms.ComboBox();
            this.ReqExam_Entry = new System.Windows.Forms.TextBox();
            this.ResExam_Entry = new System.Windows.Forms.TextBox();
            this.Arrow_Label = new System.Windows.Forms.LinkLabel();
            this.Env_Entry = new System.Windows.Forms.ComboBox();
            this.Generate_Button = new System.Windows.Forms.Button();
            this.Method_Label = new System.Windows.Forms.Label();
            this.Env_Label = new System.Windows.Forms.Label();
            this.RestCheck_Button = new System.Windows.Forms.Button();
            this.Statuscode_Label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PM_Label
            // 
            resources.ApplyResources(this.PM_Label, "PM_Label");
            this.PM_Label.LinkColor = System.Drawing.Color.Black;
            this.PM_Label.Name = "PM_Label";
            this.PM_Label.TabStop = true;
            this.PM_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.PM_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.PM_Label_LinkClicked);
            // 
            // SS_Label
            // 
            resources.ApplyResources(this.SS_Label, "SS_Label");
            this.SS_Label.LinkColor = System.Drawing.Color.Black;
            this.SS_Label.Name = "SS_Label";
            this.SS_Label.TabStop = true;
            this.SS_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.SS_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SS_Label_LinkClicked);
            // 
            // UoS_Label
            // 
            resources.ApplyResources(this.UoS_Label, "UoS_Label");
            this.UoS_Label.LinkColor = System.Drawing.Color.Black;
            this.UoS_Label.Name = "UoS_Label";
            this.UoS_Label.TabStop = true;
            this.UoS_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.UoS_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.UoS_Label_LinkClicked);
            // 
            // Url_Label
            // 
            resources.ApplyResources(this.Url_Label, "Url_Label");
            this.Url_Label.LinkColor = System.Drawing.Color.Black;
            this.Url_Label.Name = "Url_Label";
            this.Url_Label.TabStop = true;
            this.Url_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.Url_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Url_Label_LinkClicked);
            // 
            // Schema_Label
            // 
            resources.ApplyResources(this.Schema_Label, "Schema_Label");
            this.Schema_Label.LinkColor = System.Drawing.Color.Black;
            this.Schema_Label.Name = "Schema_Label";
            this.Schema_Label.TabStop = true;
            this.Schema_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.Schema_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Schema_Label_LinkClicked);
            // 
            // ReqExam_Label
            // 
            resources.ApplyResources(this.ReqExam_Label, "ReqExam_Label");
            this.ReqExam_Label.LinkColor = System.Drawing.Color.Black;
            this.ReqExam_Label.Name = "ReqExam_Label";
            this.ReqExam_Label.TabStop = true;
            this.ReqExam_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.ReqExam_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.ReqExam_Label_LinkClicked);
            // 
            // ResExam_Label
            // 
            resources.ApplyResources(this.ResExam_Label, "ResExam_Label");
            this.ResExam_Label.LinkColor = System.Drawing.Color.Black;
            this.ResExam_Label.Name = "ResExam_Label";
            this.ResExam_Label.TabStop = true;
            this.ResExam_Label.VisitedLinkColor = System.Drawing.Color.Black;
            // 
            // TS_Label
            // 
            resources.ApplyResources(this.TS_Label, "TS_Label");
            this.TS_Label.LinkColor = System.Drawing.Color.Black;
            this.TS_Label.Name = "TS_Label";
            this.TS_Label.TabStop = true;
            this.TS_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.TS_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.TS_Label_LinkClicked);
            // 
            // User_Label
            // 
            resources.ApplyResources(this.User_Label, "User_Label");
            this.User_Label.LinkColor = System.Drawing.Color.Black;
            this.User_Label.Name = "User_Label";
            this.User_Label.TabStop = true;
            this.User_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.User_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.User_Label_LinkClicked);
            // 
            // PM_Entry
            // 
            this.PM_Entry.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.PM_Entry.ForeColor = System.Drawing.SystemColors.WindowText;
            resources.ApplyResources(this.PM_Entry, "PM_Entry");
            this.PM_Entry.Name = "PM_Entry";
            // 
            // SS_Entry
            // 
            resources.ApplyResources(this.SS_Entry, "SS_Entry");
            this.SS_Entry.Name = "SS_Entry";
            // 
            // TS_Entry
            // 
            resources.ApplyResources(this.TS_Entry, "TS_Entry");
            this.TS_Entry.Name = "TS_Entry";
            // 
            // User_Entry
            // 
            resources.ApplyResources(this.User_Entry, "User_Entry");
            this.User_Entry.Name = "User_Entry";
            // 
            // UoS_Entry
            // 
            resources.ApplyResources(this.UoS_Entry, "UoS_Entry");
            this.UoS_Entry.Name = "UoS_Entry";
            // 
            // Url_Entry
            // 
            resources.ApplyResources(this.Url_Entry, "Url_Entry");
            this.Url_Entry.Name = "Url_Entry";
            // 
            // Schema_Button
            // 
            resources.ApplyResources(this.Schema_Button, "Schema_Button");
            this.Schema_Button.Name = "Schema_Button";
            this.Schema_Button.UseVisualStyleBackColor = true;
            this.Schema_Button.Click += new System.EventHandler(this.Schema_Button_Click);
            // 
            // Filename_Label
            // 
            resources.ApplyResources(this.Filename_Label, "Filename_Label");
            this.Filename_Label.Name = "Filename_Label";
            // 
            // Method_Entry
            // 
            this.Method_Entry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.Method_Entry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Method_Entry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Method_Entry.FormattingEnabled = true;
            this.Method_Entry.Items.AddRange(new object[] {
            resources.GetString("Method_Entry.Items"),
            resources.GetString("Method_Entry.Items1"),
            resources.GetString("Method_Entry.Items2"),
            resources.GetString("Method_Entry.Items3")});
            resources.ApplyResources(this.Method_Entry, "Method_Entry");
            this.Method_Entry.Name = "Method_Entry";
            // 
            // ReqExam_Entry
            // 
            resources.ApplyResources(this.ReqExam_Entry, "ReqExam_Entry");
            this.ReqExam_Entry.Name = "ReqExam_Entry";
            // 
            // ResExam_Entry
            // 
            resources.ApplyResources(this.ResExam_Entry, "ResExam_Entry");
            this.ResExam_Entry.Name = "ResExam_Entry";
            // 
            // Arrow_Label
            // 
            resources.ApplyResources(this.Arrow_Label, "Arrow_Label");
            this.Arrow_Label.LinkColor = System.Drawing.Color.Black;
            this.Arrow_Label.Name = "Arrow_Label";
            this.Arrow_Label.TabStop = true;
            this.Arrow_Label.VisitedLinkColor = System.Drawing.Color.Black;
            this.Arrow_Label.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Arrow_Label_LinkClicked);
            // 
            // Env_Entry
            // 
            this.Env_Entry.AllowDrop = true;
            this.Env_Entry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.Env_Entry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Env_Entry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Env_Entry.FormattingEnabled = true;
            this.Env_Entry.Items.AddRange(new object[] {
            resources.GetString("Env_Entry.Items"),
            resources.GetString("Env_Entry.Items1"),
            resources.GetString("Env_Entry.Items2")});
            resources.ApplyResources(this.Env_Entry, "Env_Entry");
            this.Env_Entry.Name = "Env_Entry";
            // 
            // Generate_Button
            // 
            resources.ApplyResources(this.Generate_Button, "Generate_Button");
            this.Generate_Button.Name = "Generate_Button";
            this.Generate_Button.UseVisualStyleBackColor = true;
            this.Generate_Button.Click += new System.EventHandler(this.Generate_Button_Click);
            // 
            // Method_Label
            // 
            resources.ApplyResources(this.Method_Label, "Method_Label");
            this.Method_Label.Name = "Method_Label";
            // 
            // Env_Label
            // 
            resources.ApplyResources(this.Env_Label, "Env_Label");
            this.Env_Label.Name = "Env_Label";
            // 
            // RestCheck_Button
            // 
            resources.ApplyResources(this.RestCheck_Button, "RestCheck_Button");
            this.RestCheck_Button.Name = "RestCheck_Button";
            this.RestCheck_Button.UseVisualStyleBackColor = true;
            this.RestCheck_Button.Click += new System.EventHandler(this.RestCheck_Button_Click);
            // 
            // Statuscode_Label
            // 
            resources.ApplyResources(this.Statuscode_Label, "Statuscode_Label");
            this.Statuscode_Label.Name = "Statuscode_Label";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Statuscode_Label);
            this.Controls.Add(this.RestCheck_Button);
            this.Controls.Add(this.Env_Label);
            this.Controls.Add(this.Method_Label);
            this.Controls.Add(this.Generate_Button);
            this.Controls.Add(this.Env_Entry);
            this.Controls.Add(this.Arrow_Label);
            this.Controls.Add(this.ResExam_Entry);
            this.Controls.Add(this.ReqExam_Entry);
            this.Controls.Add(this.Method_Entry);
            this.Controls.Add(this.Filename_Label);
            this.Controls.Add(this.Schema_Button);
            this.Controls.Add(this.Url_Entry);
            this.Controls.Add(this.UoS_Entry);
            this.Controls.Add(this.User_Entry);
            this.Controls.Add(this.TS_Entry);
            this.Controls.Add(this.SS_Entry);
            this.Controls.Add(this.PM_Entry);
            this.Controls.Add(this.User_Label);
            this.Controls.Add(this.TS_Label);
            this.Controls.Add(this.ResExam_Label);
            this.Controls.Add(this.ReqExam_Label);
            this.Controls.Add(this.Schema_Label);
            this.Controls.Add(this.Url_Label);
            this.Controls.Add(this.UoS_Label);
            this.Controls.Add(this.SS_Label);
            this.Controls.Add(this.PM_Label);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.LinkLabel PM_Label;
        private System.Windows.Forms.LinkLabel SS_Label;
        private System.Windows.Forms.LinkLabel UoS_Label;
        private System.Windows.Forms.LinkLabel Url_Label;
        private System.Windows.Forms.LinkLabel Schema_Label;
        private System.Windows.Forms.LinkLabel ReqExam_Label;
        private System.Windows.Forms.LinkLabel ResExam_Label;
        private System.Windows.Forms.LinkLabel TS_Label;
        private System.Windows.Forms.LinkLabel User_Label;
        private System.Windows.Forms.TextBox PM_Entry;
        private System.Windows.Forms.TextBox SS_Entry;
        private System.Windows.Forms.TextBox TS_Entry;
        private System.Windows.Forms.TextBox User_Entry;
        private System.Windows.Forms.TextBox UoS_Entry;
        private System.Windows.Forms.TextBox Url_Entry;
        private System.Windows.Forms.Button Schema_Button;
        private System.Windows.Forms.Label Filename_Label;
        private System.Windows.Forms.ComboBox Method_Entry;
        private System.Windows.Forms.TextBox ReqExam_Entry;
        private System.Windows.Forms.TextBox ResExam_Entry;
        private System.Windows.Forms.LinkLabel Arrow_Label;
        private System.Windows.Forms.ComboBox Env_Entry;
        private System.Windows.Forms.Button Generate_Button;
        private System.Windows.Forms.Label Method_Label;
        private System.Windows.Forms.Label Env_Label;
        private System.Windows.Forms.Button RestCheck_Button;
        private System.Windows.Forms.Label Statuscode_Label;
    }
}

