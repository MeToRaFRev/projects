import json
import tkinter
import requests
import base64
import urllib3
urllib3.disable_warnings()
method = ""
auth = ""

def authGenerate(user,passwd):
    print(type(user))
    UnP = user.get()+':'+passwd.get()
    auth = base64.b64encode(UnP.encode('utf-8'))

def authClicked():
    authWindow = tkinter.Toplevel()
    authWindow.title('Authentication')
    authWindow.geometry("250x100+775+350")
    authWindow.resizable(False,False)
    tkinter.Label(authWindow,text='Basic Authentication').place(relx=0.25,rely=0.075,anchor='center')
    tkinter.Label(authWindow,text='Username:').place(relx=0.15,rely=0.3,anchor='center')
    tkinter.Label(authWindow,text='Password:').place(relx=0.145,rely=0.6,anchor='center')
    user = tkinter.Entry(authWindow)
    user.place(relx=0.55,rely=0.3,anchor='center')
    passwd = tkinter.Entry(authWindow)
    passwd.place(relx=0.55,rely=0.6,anchor='center')
    authButton = tkinter.Button(authWindow,text='Generate',command=lambda:authGenerate(user,passwd))
    authButton.place(relx=0.5,rely=0.85,anchor='center')
    #

def dropdownChange(selection):
    if selection == 'GET':
        print('get')

def sendClicked():
    if 'http' not in urlEntry.get():
        print('Missing http/s')
        return
    elif '.' not in urlEntry.get():
        print('your URL isnt complete')
        return
    print('sending requests')

window = tkinter.Tk()
window.title('REST Client')
window.geometry("750x750+525+150")
window.resizable(False,False)
dropdownVar = tkinter.StringVar(window)
methods = { 'GET','POST','DELETE','PUT','OPTIONS'}
dropdownVar.set('GET')
dropdownMenu = tkinter.OptionMenu(window,dropdownVar,*methods,command=dropdownChange)
dropdownMenu.place(relx=0.09,rely=0.05,anchor='center')
urlEntry = tkinter.Entry(window)
urlEntry.place(relx=0.475,rely=0.05,anchor='center',height=25,width=450)
urlEntry.focus_set()
sendButton = tkinter.Button(window,text='Send →',command=lambda:sendClicked())
sendButton.place(relx=0.925,rely=0.05,anchor='center')
authButton = tkinter.Button(window,text='Auth',command=lambda:authClicked())
authButton.place(relx=0.09,rely=0.1,anchor='center')

window.mainloop()
